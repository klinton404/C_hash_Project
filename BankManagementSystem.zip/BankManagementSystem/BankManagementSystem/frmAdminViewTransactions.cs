﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Windows.Forms;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Diagnostics;
using System.Collections.Generic;
using System.Text;

namespace BankManagementSystem
{
    public partial class frmAdminViewTransactions : Form
    {
        public frmAdminViewTransactions()
        {
            InitializeComponent();
            this.dgvAllTransactions.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvAllTransactions_CellFormatting);
        }

        private void frmAdminViewTransactions_Load(object sender, EventArgs e)
        {
            SetupFilterControls();
            LoadAllTransactions();
        }

        private void SetupFilterControls()
        {
            cmbTransactionType.Items.Add("All");
            cmbTransactionType.Items.Add("Deposit");
            cmbTransactionType.Items.Add("Withdrawal");
            cmbTransactionType.Items.Add("Transfer");
            cmbTransactionType.Items.Add("Loan");
            cmbTransactionType.SelectedIndex = 0;

            dtpStartDate.Value = DateTime.Now.AddMonths(-1);
            dtpEndDate.Value = DateTime.Now;
        }

        private void LoadAllTransactions()
        {
            try
            {
                using (SqlConnection con = DatabaseHelper.GetConnection())
                {
                    var queryBuilder = new StringBuilder(@"
                        SELECT 
                            t.TransactionID, t.TransactionDate, t.TransactionType,
                            source_a.AccountNumber AS SourceAccount, t.Amount,
                            ISNULL(dest_a.AccountNumber, 'N/A') AS DestinationAccount
                        FROM Transactions t
                        JOIN Accounts source_a ON t.AccountID = source_a.AccountID
                        LEFT JOIN Accounts dest_a ON t.DestinationAccountID = dest_a.AccountID
                        WHERE 1=1");

                    var parameters = new Dictionary<string, object>();

                    if (!string.IsNullOrWhiteSpace(txtSearchAccount.Text))
                    {
                        queryBuilder.Append(" AND (source_a.AccountNumber LIKE @AccountNumber OR dest_a.AccountNumber LIKE @AccountNumber)");
                        parameters["@AccountNumber"] = "%" + txtSearchAccount.Text.Trim() + "%";
                    }

                    if (cmbTransactionType.SelectedItem.ToString() != "All")
                    {
                        queryBuilder.Append(" AND t.TransactionType = @TransactionType");
                        parameters["@TransactionType"] = cmbTransactionType.SelectedItem.ToString();
                    }

                    queryBuilder.Append(" AND t.TransactionDate BETWEEN @StartDate AND @EndDate");
                    parameters["@StartDate"] = dtpStartDate.Value.Date;
                    parameters["@EndDate"] = dtpEndDate.Value.Date.AddDays(1).AddTicks(-1);

                    queryBuilder.Append(" ORDER BY t.TransactionDate DESC");

                    using (SqlCommand cmd = new SqlCommand(queryBuilder.ToString(), con))
                    {
                        foreach (var param in parameters)
                        {
                            cmd.Parameters.AddWithValue(param.Key, param.Value);
                        }

                        DataTable dt = new DataTable();
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        adapter.Fill(dt);

                        dgvAllTransactions.DataSource = dt;
                        CustomizeDataGridView();
                        CalculateAndDisplayTotal(); // Call the new method to calculate total
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load transaction data.\n" + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CustomizeDataGridView()
        {
            // ... (same as before) ...
        }

        private void dgvAllTransactions_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.dgvAllTransactions.Columns[e.ColumnIndex].Name == "Amount" && e.Value != null)
            {
                decimal amount = Convert.ToDecimal(e.Value);
                var culture = new CultureInfo("bn-BD");
                e.Value = amount.ToString("C", culture);
                e.FormattingApplied = true;
            }
        }

        private void CalculateAndDisplayTotal()
        {
            decimal totalAmount = 0;
            // Loop through the 'Amount' column of the grid to sum the values
            foreach (DataGridViewRow row in dgvAllTransactions.Rows)
            {
                // We use the underlying DataRow to get the raw decimal value, not the formatted string
                DataRowView drv = (DataRowView)row.DataBoundItem;
                totalAmount += Convert.ToDecimal(drv["Amount"]);
            }

            // Display the total in the new label, formatted as currency
            var culture = new CultureInfo("bn-BD");
            lblTotalAmount.Text = totalAmount.ToString("C", culture);
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            LoadAllTransactions();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtSearchAccount.Clear();
            cmbTransactionType.SelectedIndex = 0;
            dtpStartDate.Value = DateTime.Now.AddMonths(-1);
            dtpEndDate.Value = DateTime.Now;
            LoadAllTransactions();
        }

        private void btnGeneratePdf_Click(object sender, EventArgs e)
        {
            // ... (same as before) ...
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
